# phpwebservice
Simple CRUD using PHP MySQL Ajax Bootstrap
